import React, { useState, useEffect } from 'react';

// --- COMPOSANTS INTERNES ---

const BoxscoreTable = ({ title, players, color }) => {
  const formatPlayerTime = (sec) => `${Math.floor(sec / 60).toString().padStart(2, '0')}:${(sec % 60).toString().padStart(2, '0')}`;
  return (
    <div className="boxscore-team">
      <h3 className="boxscore-title" style={{ color: color }}>{title}</h3>
      <table className="boxscore-table">
        <thead>
          <tr>
            <th className="text-left">N°</th>
            <th className="text-left">JOUEUR</th>
            <th>MIN</th>
            <th>PTS</th>
            <th>TIRS</th>
            <th>3PT</th>
            <th>LF</th>
            <th>+/-</th>
            <th>AST</th>
            <th>REB</th>
            <th>STL</th>
            <th>BLK</th>
            <th>TOV</th>
            <th>FLS</th>
          </tr>
        </thead>
        <tbody>
          {players.map(p => {
            const pmColor = p.plusMinus > 0 ? 'var(--success)' : (p.plusMinus < 0 ? 'var(--danger)' : 'var(--text-muted)');
            return (
              <tr key={p.id}>
                <td className="text-left">{p.number}</td>
                <td className="text-left">{p.name} {p.status === 'court' && <span style={{color: 'var(--accent-orange)'}}>*</span>}</td>
                <td>{formatPlayerTime(p.timePlayed)}</td>
                <td className="stat-highlight">{p.points}</td>
                <td>{p.fg2m + p.fg3m}/{p.fg2a + p.fg3a}</td>
                <td>{p.fg3m}/{p.fg3a}</td>
                <td>{p.ftm}/{p.fta}</td>
                <td style={{ color: pmColor, fontWeight: 'bold' }}>{p.plusMinus > 0 ? `+${p.plusMinus}` : p.plusMinus}</td>
                <td>{p.ast}</td>
                <td className="stat-highlight">{p.oreb + p.dreb}</td>
                <td>{p.stl}</td>
                <td>{p.blk}</td>
                <td>{p.tov}</td>
                <td className={p.fouls >= 5 ? "fouls-alert" : ""}>{p.fouls}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

const PlayerCard = ({ team, player, onPlayerClick, pendingSubs, pendingAction, onConfirm, hasGlobalAction, pendingAssist, activeActionType }) => {
  const isSubSelected = pendingSubs && pendingSubs.includes(player.id);
  const isPendingScore = pendingAction?.playerId === player.id;
  const isFouledOut = player.fouls >= 5;
  
  let isTargetable = false;
  if (activeActionType === 'SUB') {
      isTargetable = !(isFouledOut && player.status === 'bench');
  } else if (pendingAssist) {
      isTargetable = (team === pendingAssist.team && player.id !== pendingAssist.scorerId && player.status === 'court');
  } else if (hasGlobalAction) {
      isTargetable = (player.status === 'court' && !isPendingScore);
  }

  return (
    <div 
        className={`player-card ${isSubSelected ? 'is-sub-selected' : ''} ${isPendingScore ? 'pending' : ''} ${isTargetable ? 'is-targetable' : ''} ${(isFouledOut && player.status === 'bench') ? 'fouled-out-bench' : ''}`} 
        onClick={() => isTargetable && onPlayerClick(activeActionType, team, player.id, null)}
    >
      {isFouledOut && <div className="badge-exclu">5 FAUTES</div>}
      <div className="player-header">
        <div className="sb-player-header-info"><span className="player-number">{player.number}</span><span>{player.name}</span></div>
        <span className="player-time">{`${Math.floor(player.timePlayed / 60).toString().padStart(2, '0')}:${(player.timePlayed % 60).toString().padStart(2, '0')}`}</span>
      </div>
      <div className="player-stats">
        <span className="pts">{player.points} pts</span>
        <div className="fouls-container">
          {[1, 2, 3, 4, 5].map(idx => <div key={idx} className={`foul-box ${idx <= player.fouls ? 'filled' : ''} ${idx === 5 && player.fouls === 5 ? 'danger' : ''}`} />)}
        </div>
      </div>
      <div className="minor-stats">
        <span>AS: <span>{player.ast}</span></span>
        <span>REB: <span>{player.oreb + player.dreb}</span></span>
        <span>ST: <span>{player.stl}</span></span>
        <span>BL: <span>{player.blk}</span></span>
        <span>TO: <span>{player.tov}</span></span>
      </div>
      {isPendingScore && (
        <div className="validation-overlay" onClick={e => e.stopPropagation()}>
          <button className="btn-validate" onClick={() => onConfirm('VALIDATED')}>V</button>
          <button className="btn-miss" onClick={() => onConfirm('MISSED')}>X</button>
        </div>
      )}
    </div>
  );
};

// --- COMPOSANT PRINCIPAL ---

export default function Scoreboard({ teamA, teamB, savedStatsA, savedStatsB, isFinished, onExit, onMatchFinished }) {
  
  // --- PARE-FEU DE SAUVEGARDE (Évite les crashs d'écran blanc) ---
  const getSafeSave = () => {
    try {
      const saved = localStorage.getItem('basketMatchSave');
      if (!saved) return null;
      const parsed = JSON.parse(saved);
      // Vérifie si la sauvegarde appartient bien à l'équipe A actuelle
      const isRightMatch = parsed.playersA?.length > 0 && teamA?.players?.some(p => p.id === parsed.playersA[0]?.id);
      return isRightMatch ? parsed : null;
    } catch (e) {
      return null;
    }
  };

  const initPlayers = (team) => {
    const playersList = team?.players || [];
    return playersList.map((p, index) => ({
      ...p,
      status: index < 5 ? 'court' : 'bench',
      points: 0, fouls: 0, ast: 0, oreb: 0, dreb: 0, tov: 0, stl: 0, blk: 0, timePlayed: 0,
      ftm: 0, fta: 0, fg2m: 0, fga: 0, fg3m: 0, fg3a: 0, plusMinus: 0
    }));
  };

  const safeSave = getSafeSave();

  const [playersA, setPlayersA] = useState(() => {
    if (savedStatsA) return savedStatsA;
    return safeSave ? safeSave.playersA : initPlayers(teamA);
  });

  const [playersB, setPlayersB] = useState(() => {
    if (savedStatsB) return savedStatsB;
    return safeSave ? safeSave.playersB : initPlayers(teamB);
  });

  const [time, setTime] = useState(() => {
    if (isFinished) return 0;
    return safeSave ? safeSave.time : 600;
  });

  const [period, setPeriod] = useState(() => {
    if (isFinished) return 'FIN';
    return safeSave ? safeSave.period : 'Q1';
  });

  const [history, setHistory] = useState(() => {
    return safeSave ? safeSave.history : [];
  });

  const [isMatchOver, setIsMatchOver] = useState(isFinished || false);
  const [isRunning, setIsRunning] = useState(false);
  const [currentView, setCurrentView] = useState(isFinished ? 'boxscore' : 'court');

  const [activeAction, setActiveAction] = useState(null);
  const [pendingSubs, setPendingSubs] = useState([]);
  const [pendingAction, setPendingAction] = useState(null);
  const [pendingAssist, setPendingAssist] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editMin, setEditMin] = useState(0);
  const [editSec, setEditSec] = useState(0);

  const scoreA = playersA.reduce((sum, p) => sum + p.points, 0);
  const scoreB = playersB.reduce((sum, p) => sum + p.points, 0);

  useEffect(() => {
    if (!isFinished) {
      const gameState = { playersA, playersB, time, period, history, isMatchOver };
      localStorage.setItem('basketMatchSave', JSON.stringify(gameState));
    }
  }, [playersA, playersB, time, period, history, isMatchOver, isFinished]);

  const handleFinishMatch = () => {
    if (window.confirm("Terminer définitivement le match et sauvegarder les stats ?")) {
      setIsRunning(false);
      setIsMatchOver(true);
      setCurrentView('boxscore');
      if (onMatchFinished) {
        onMatchFinished(scoreA, scoreB, playersA, playersB);
      }
    }
  };

  const handleSaveTime = (e) => {
    e.stopPropagation();
    setTime(parseInt(editMin || 0) * 60 + parseInt(editSec || 0));
    setIsEditing(false);
  };

  const handleResetTime = (e) => {
    e.stopPropagation();
    if(window.confirm("Réinitialiser le chrono à 10:00 ?")) {
      setTime(600);
      setIsRunning(false);
    }
  };

  const nextPeriod = () => {
    let nextP;
    if (period === 'Q1') nextP = 'Q2';
    else if (period === 'Q2') nextP = 'Q3';
    else if (period === 'Q3') nextP = 'Q4';
    else if (period === 'Q4' || period.startsWith('OT')) {
      const otNumber = period === 'Q4' ? 1 : parseInt(period.replace('OT', '')) + 1;
      nextP = `OT${otNumber}`;
    }
    if (window.confirm(`Passer à ${nextP} et remettre le chrono à 10:00 ?`)) {
      setPeriod(nextP);
      setTime(600);
      setIsRunning(false);
    }
  };

  const deleteAction = (index) => {
    if (isMatchOver) return;
    const actionToDelete = history[index];
    if (actionToDelete.type === 'SUB') {
      setHistory(prev => prev.filter((_, i) => i !== index));
      return;
    }
    const { team, playerId, type, value } = actionToDelete;
    const isA = team === 'A';
    const set = isA ? setPlayersA : setPlayersB;

    set(prev => prev.map(p => {
      if (p.id === playerId) {
        let up = { ...p };
        if (type === 'SCORE') {
          up.points -= value;
          if (value === 1) { up.ftm -= 1; up.fta -= 1; }
          else if (value === 2) { up.fg2m -= 1; up.fg2a -= 1; }
          else { up.fg3m -= 1; up.fg3a -= 1; }
        }
        if (type === 'FOUL') up.fouls -= 1;
        if (type === 'OREB') up.oreb -= 1;
        if (type === 'DREB') up.dreb -= 1;
        if (type === 'STL') up.stl -= 1;
        if (type === 'BLK') up.blk -= 1;
        if (type === 'TOV') up.tov -= 1;
        if (type === 'AST') up.ast -= 1;
        return up;
      }
      return p;
    }));

    if (type === 'SCORE') {
      const otherSet = isA ? setPlayersB : setPlayersA;
      const updatePM = (list, val) => list.map(p => p.status === 'court' ? { ...p, plusMinus: p.plusMinus + val } : p);
      set(prev => updatePM(prev, -value));
      otherSet(prev => updatePM(prev, value));
    }
    setHistory(prev => prev.filter((_, i) => i !== index));
  };

  useEffect(() => {
    let interval = null;
    if (isRunning && time > 0) {
      interval = setInterval(() => {
        setTime(t => t - 1);
        setPlayersA(prev => prev.map(p => p.status === 'court' ? { ...p, timePlayed: p.timePlayed + 1 } : p));
        setPlayersB(prev => prev.map(p => p.status === 'court' ? { ...p, timePlayed: p.timePlayed + 1 } : p));
      }, 1000);
    } else if (time === 0) setIsRunning(false);
    return () => clearInterval(interval);
  }, [isRunning, time]);

  const handleAction = (type, team, pid, val) => {
    if (isMatchOver) return;
    if (pendingAssist) {
      if (team !== pendingAssist.team || pid === pendingAssist.scorerId) return;
      const set = team === 'A' ? setPlayersA : setPlayersB;
      set(prev => prev.map(p => p.id === pid ? { ...p, ast: p.ast + 1 } : p));
      setHistory([{ team, playerId: pid, type: 'AST', time, period }, ...history]);
      setPendingAssist(null);
      return;
    }
    if (type === 'SUB' || activeAction?.type === 'SUB') {
      if (pendingSubs.includes(pid)) {
        setPendingSubs(prev => prev.filter(id => id !== pid));
      } else {
        setPendingSubs(prev => [...prev, pid]);
      }
      return;
    }
    const actionType = activeAction?.type;
    const actionValue = activeAction?.value;
    if (!actionType) return;
    const isA = team === 'A';
    const set = isA ? setPlayersA : setPlayersB;
    if (['PLUS1', 'PLUS2', 'PLUS3'].includes(actionType)) { 
        setPendingAction({ team, playerId: pid, value: actionValue }); 
        setActiveAction(null); 
        return; 
    }
    set(prev => prev.map(p => {
      if (p.id === pid) {
        if (actionType === 'FOUL') {
           const newF = p.fouls + 1;
           if (newF === 5) { setIsRunning(false); setActiveAction({type:'SUB'}); setPendingSubs([p.id]); }
           return { ...p, fouls: newF };
        }
        if (actionType === 'OREB') return { ...p, oreb: p.oreb + 1 };
        if (actionType === 'DREB') return { ...p, dreb: p.dreb + 1 };
        if (actionType === 'STL') return { ...p, stl: p.stl + 1 };
        if (actionType === 'BLK') return { ...p, blk: p.blk + 1 };
        if (actionType === 'TOV') return { ...p, tov: p.tov + 1 };
      }
      return p;
    }));
    if (actionType !== 'SUB') {
      setHistory([{ team, playerId: pid, type: actionType, time, period }, ...history]);
    }
    setActiveAction(null);
  };

  const handleConfirmSubs = () => {
    if (pendingSubs.length === 0) return;
    const isTeamA = playersA.some(p => pendingSubs.includes(p.id));
    const activeTeam = isTeamA ? 'A' : 'B';
    const playersList = isTeamA ? playersA : playersB;
    const pIn = playersList.filter(p => pendingSubs.includes(p.id) && p.status === 'bench');
    const pOut = playersList.filter(p => pendingSubs.includes(p.id) && p.status === 'court');
    const updateStatus = (list) => list.map(p => {
        if (pendingSubs.includes(p.id)) return { ...p, status: p.status === 'court' ? 'bench' : 'court' };
        return p;
    });
    if (isTeamA) setPlayersA(updateStatus(playersA));
    else setPlayersB(updateStatus(playersB));
    setHistory([{
      type: 'SUB', team: activeTeam, playerId: null,
      details: `Sort : ${pOut.map(p => '#' + p.number + ' ' + p.name).join(', ')} | Entre : ${pIn.map(p => '#' + p.number + ' ' + p.name).join(', ')}`,
      time, period
    }, ...history]);
    setPendingSubs([]);
    setActiveAction(null);
  };

  const confirmScore = (status) => {
    if (!pendingAction) return;
    const { team, playerId, value } = pendingAction;
    const isA = team === 'A';
    if (status === 'VALIDATED') {
      const updateList = (list, scoringTeam) => list.map(p => {
        let up = { ...p };
        if (p.id === playerId) {
          up.points += value;
          if (value === 1) { up.ftm += 1; up.fta += 1; }
          else if (value === 2) { up.fg2m += 1; up.fg2a += 1; }
          else { up.fg3m += 1; up.fg3a += 1; }
        }
        if (p.status === 'court') {
          up.plusMinus += (scoringTeam === isA) ? value : -value;
        }
        return up;
      });
      setPlayersA(updateList(playersA, true));
      setPlayersB(updateList(playersB, false));
      setHistory([{ team, playerId, value, type: 'SCORE', time, period }, ...history]);
      if (value > 1) { setTimeout(() => setPendingAssist({ team, scorerId: playerId }), 10); }
    } else {
      const updateMiss = (list) => list.map(p => {
        if (p.id === playerId) {
          let up = { ...p };
          if (value === 1) up.fta += 1;
          else if (value === 2) up.fg2a += 1;
          else up.fg3a += 1;
          return up;
        }
        return p;
      });
      isA ? setPlayersA(updateMiss(playersA)) : setPlayersB(updateMiss(playersB));
    }
    setPendingAction(null);
    setActiveAction(null);
  };

  return (
    <div className="scoreboard-container">
      <div className="tm-flex-between" style={{ marginBottom:'20px' }}>
        <button className="btn-undo" onClick={onExit}>⬅ RETOUR</button>
        <div className="view-tabs" style={{ margin:0 }}>
            <button className={`btn-tab ${currentView === 'court' ? 'active' : ''}`} onClick={() => !isFinished && setCurrentView('court')}>TERRAIN</button>
            <button className={`btn-tab ${currentView === 'boxscore' ? 'active' : ''}`} onClick={() => setCurrentView('boxscore')}>STATS</button>
            {isMatchOver && (
              <button onClick={() => window.print()} className="sb-btn-print">IMPRIMER PDF 📄</button>
            )}
            {!isMatchOver && (
              <button onClick={handleFinishMatch} className="sb-btn-finish">TERMINER LE MATCH 🏁</button>
            )}
        </div>
      </div>
      
      <div className="header-stats">
        <div className="score-board"><h2>{teamA?.name}</h2><p className="score-text team-score">{scoreA}</p></div>
        <div className="timer-section">
          <div className="time-display sb-time-display-wrapper">
            {isEditing ? (
              <div className="time-edit" onClick={e => e.stopPropagation()}>
                <input type="number" value={editMin} onChange={e => setEditMin(e.target.value)} className="sb-time-edit-input" />
                <span>:</span>
                <input type="number" value={editSec} onChange={e => setEditSec(e.target.value)} className="sb-time-edit-input" />
                <button onClick={handleSaveTime} className="sb-time-edit-btn">OK</button>
              </div>
            ) : (
              <span onClick={(e) => { if(!isMatchOver) { e.stopPropagation(); setIsEditing(true); setEditMin(Math.floor(time/60)); setEditSec(time%60); }}}>
                {Math.floor(time/60)}:{time%60 < 10 ? '0'+time%60 : time%60}
              </span>
            )}
          </div>
          {!isMatchOver && (
            <div className="sb-timer-controls">
              <button onClick={() => setIsRunning(!isRunning)} className={`sb-btn-timer ${isRunning ? 'sb-btn-pause' : 'sb-btn-start'}`}>
                {isRunning ? 'PAUSE' : 'START'}
              </button>
              <button onClick={handleResetTime} className="sb-btn-timer sb-btn-reset">RESET</button>
            </div>
          )}
          <div className="sb-period-container">
            <button onClick={!isMatchOver ? nextPeriod : null} className={`sb-btn-period ${isMatchOver ? 'disabled' : 'clickable'}`}>
              PÉRIODE : {period}
            </button>
          </div>
        </div>
        <div className="score-board"><h2>{teamB?.name}</h2><p className="score-text team-score blue">{scoreB}</p></div>
      </div>

      {currentView === 'court' ? (
        <>
          <div className={`action-bar-container ${pendingAssist ? 'success-mode' : (activeAction?.type === 'SUB' ? 'sub-mode' : 'active-mode')}`}>
            {pendingAssist ? (
              <div className="action-buttons">
                <span className="sb-assist-msg">QUI A FAIT LA PASSE ?</span>
                <button className="btn-miss" onClick={() => setPendingAssist(null)}>SANS PASSEUR</button>
              </div>
            ) : activeAction?.type === 'SUB' ? (
              <div className="action-buttons">
                <span className="sb-sub-msg">MODE REMPLACEMENT</span>
                <button className="btn-sub-validate" onClick={handleConfirmSubs}>VALIDER LES CHANGEMENTS</button>
                <button className="action-btn cancel-btn" onClick={() => {setActiveAction(null); setPendingSubs([]);}}>ANNULER</button>
              </div>
            ) : (
              <div className="action-buttons">
                {['PLUS1', 'PLUS2', 'PLUS3'].map(type => (
                  <button key={type} className={`action-btn sb-action-btn-pts ${activeAction?.type === type ? 'selected' : ''}`} onClick={() => setActiveAction({type, value: parseInt(type.replace('PLUS', ''))})}>
                    +{type.replace('PLUS', '')}
                  </button>
                ))}
                <div className="sb-divider"></div>
                {['OREB', 'DREB', 'STL', 'BLK', 'TOV', 'FOUL', 'SUB'].map(type => {
                  let btnClass = 'sb-action-btn-default';
                  if (type === 'FOUL') btnClass = 'sb-action-btn-foul';
                  if (type.includes('REB')) btnClass = 'sb-action-btn-reb';
                  if (type === 'SUB') btnClass = 'sb-action-btn-sub';
                  if (type === 'STL' || type === 'BLK') btnClass = 'sb-action-btn-def';
                  if (type === 'TOV') btnClass = 'sb-action-btn-tov';
                  return (
                    <button key={type} className={`action-btn ${btnClass} ${activeAction?.type === type ? 'selected' : ''}`} onClick={() => setActiveAction({type, value: null})}>
                      {type}
                    </button>
                  );
                })}
                {activeAction && <button onClick={() => setActiveAction(null)} className="sb-btn-cancel-action">ANNULER X</button>}
              </div>
            )}
          </div>

          <div className="bento-teams-container">
            <div className="bento-team">
                <h3 className="bento-zone-title">{teamA?.name}</h3>
                <div className="players-grid">
                  {playersA.filter(p => p.status === 'court').map(p => <PlayerCard key={p.id} team="A" player={p} onPlayerClick={handleAction} pendingSubs={pendingSubs} pendingAction={pendingAction} onConfirm={confirmScore} hasGlobalAction={!!activeAction || !!pendingAssist} pendingAssist={pendingAssist} activeActionType={activeAction?.type} />)}
                </div>
                <p className="sb-bench-title">BANC</p>
                <div className="players-grid">
                  {playersA.filter(p => p.status === 'bench').map(p => <PlayerCard key={p.id} team="A" player={p} onPlayerClick={handleAction} pendingSubs={pendingSubs} pendingAction={pendingAction} onConfirm={confirmScore} hasGlobalAction={!!activeAction || !!pendingAssist} pendingAssist={pendingAssist} activeActionType={activeAction?.type} />)}
                </div>
            </div>
            <div className="bento-team">
                <h3 className="bento-zone-title">{teamB?.name}</h3>
                <div className="players-grid">
                  {playersB.filter(p => p.status === 'court').map(p => <PlayerCard key={p.id} team="B" player={p} onPlayerClick={handleAction} pendingSubs={pendingSubs} pendingAction={pendingAction} onConfirm={confirmScore} hasGlobalAction={!!activeAction || !!pendingAssist} pendingAssist={pendingAssist} activeActionType={activeAction?.type} />)}
                </div>
                <p className="sb-bench-title">BANC</p>
                <div className="players-grid">
                  {playersB.filter(p => p.status === 'bench').map(p => <PlayerCard key={p.id} team="B" player={p} onPlayerClick={handleAction} pendingSubs={pendingSubs} pendingAction={pendingAction} onConfirm={confirmScore} hasGlobalAction={!!activeAction || !!pendingAssist} pendingAssist={pendingAssist} activeActionType={activeAction?.type} />)}
                </div>
            </div>
          </div>
        </>
      ) : (
        <div className="boxscore-container">
          <BoxscoreTable title={teamA?.name} players={playersA} color="var(--accent-orange)" />
          <BoxscoreTable title={teamB?.name} players={playersB} color="var(--accent-blue)" />
        </div>
      )}

      {/* --- HISTORIQUE --- */}
      <div className="sb-history-panel">
        <h3 className="sb-history-title">HISTORIQUE DES ACTIONS</h3>
        <div className="sb-history-list">
          {history.length === 0 ? (
            <p className="sb-history-empty">Aucune action enregistrée</p>
          ) : (
            history.map((act, i) => {
              const teamPlayers = act.team === 'A' ? playersA : playersB;
              const playerInfo = teamPlayers.find(p => p.id === act.playerId);
              const actionColor = act.team === 'A' ? 'var(--accent-orange)' : 'var(--accent-blue)';
              
              return (
                <div key={i} className="sb-history-item" style={{ borderLeft: `4px solid ${actionColor}` }}>
                  <span className="sb-history-time"><strong>{act.period}</strong> {Math.floor(act.time/60)}:{act.time%60 < 10 ? '0'+act.time%60 : act.time%60}</span>
                  <span className="sb-history-content">
                    {act.type === 'SUB' ? (
                      <span style={{ color: actionColor }}>🔄 REMPLACEMENT {act.details}</span>
                    ) : (
                      <span style={{ color: actionColor }}>
                        {act.type === 'AST' ? 'ASSIST' : act.type} {act.value ? `(+${act.value}pts)` : ''} — #{playerInfo?.number} {playerInfo?.name}
                      </span>
                    )}
                  </span>
                  {!isMatchOver && (
                    <button onClick={() => { if(window.confirm("Supprimer cette action ?")) deleteAction(i) }} className="sb-btn-delete-action">SUPPRIMER X</button>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}