import React, { useState } from 'react';

export default function TournamentManager({ tourney, setTournaments, onLaunchMatch }) {
  const [activeTab, setActiveTab] = useState("poules");
  const [teamName, setTeamName] = useState("");
  const [editId, setEditId] = useState(null);
  const [pName, setPName] = useState("");
  const [pNum, setPNum] = useState("");
  const [groupCount, setGroupCount] = useState(1);

  const update = (data) => setTournaments(prev => prev.map(t => t.id === tourney.id ? { ...t, ...data } : t));

  const handleLaunchMatch = (matchId) => {
    let match = tourney.schedule.find(m => m.id === matchId);
    if (!match && tourney.playoffs) {
      match = tourney.playoffs.matches.find(m => m.id === matchId);
    }
    if (match) {
      onLaunchMatch(matchId);
    }
  };

  const generateDrawAndSchedule = () => {
    if (!window.confirm("Cela va écraser les poules et le planning actuels. Continuer ?")) return;

    const n = parseInt(groupCount);
    if (isNaN(n) || n < 1) return;

    const shuffled = [...tourney.teams].sort(() => Math.random() - 0.5);
    const updatedTeams = shuffled.map((t, i) => ({ ...t, groupId: (i % n) + 1 }));

    const newSchedule = [];
    for (let g = 1; g <= n; g++) {
      const gTeams = updatedTeams.filter(t => t.groupId === g);
      for (let i = 0; i < gTeams.length; i++) {
        for (let j = i + 1; j < gTeams.length; j++) {
          newSchedule.push({ 
            id: `m_${Date.now()}_g${g}_${i}${j}`, 
            group: g, 
            teamA: gTeams[i], 
            teamB: gTeams[j], 
            status: 'pending', 
            scoreA: 0, 
            scoreB: 0 
          });
        }
      }
    }

    update({ 
      teams: updatedTeams, 
      schedule: newSchedule, 
      qualifiedSettings: Object.fromEntries(Array.from({length:n}, (_,i)=>[i+1,2])),
      playoffs: null 
    });
  };

  const generatePlayoffs = (size) => {
    if (tourney.playoffs && !window.confirm("Écraser la phase finale existante ?")) return;
    const qualifiedTeams = [];
    const savedGroupIds = [...new Set(tourney.teams.map(t => t.groupId).filter(g => g !== null))].sort((a,b) => a-b);
    
    savedGroupIds.forEach(gNum => {
      const standings = getGroupStandings(gNum);
      const limit = tourney.qualifiedSettings?.[gNum] || 2;
      qualifiedTeams.push(...standings.slice(0, limit));
    });

    if (qualifiedTeams.length < size) {
        alert(`Pas assez de qualifiés (${qualifiedTeams.length}) pour un tableau de ${size}.`);
        return;
    }

    const matches = [];
    for (let i = 0; i < size / 2; i++) {
        matches.push({
            id: `playoff_${Date.now()}_${i}`,
            teamA: qualifiedTeams[i],
            teamB: qualifiedTeams[size - 1 - i],
            scoreA: 0, scoreB: 0, status: 'pending', label: size === 2 ? "FINALE" : (size === 4 ? `DEMI-FINALE ${i+1}` : `QUART DE FINALE ${i+1}`)
        });
    }
    update({ playoffs: { size, matches, status: 'started' } });
    setActiveTab("finale");
  };

  const addTeam = () => {
    if (!teamName.trim()) return;
    update({ teams: [...tourney.teams, { id: "tm_" + Date.now(), name: teamName, players: [], groupId: null }] });
    setTeamName("");
  };

  const addPlayer = (tid) => {
    if (!pName.trim() || !pNum.trim()) return;
    const newPlayer = { id: "p_" + Date.now(), name: pName, number: pNum, licenseStatus: 'to_check', paid: 0, totalDue: 20 };
    update({ teams: tourney.teams.map(t => t.id === tid ? { ...t, players: [...t.players, newPlayer] } : t) });
    setPName(""); setPNum("");
  };

  const updatePlayerFinance = (teamId, playerId, field, value) => {
    const val = parseFloat(value) || 0;
    update({ teams: tourney.teams.map(t => t.id === teamId ? { ...t, players: t.players.map(p => p.id === playerId ? { ...p, [field]: val } : p) } : t) });
  };

  const renderPlayerColumn = (title, status, color, team) => {
    const filteredPlayers = team.players.filter(p => p.licenseStatus === status || (!p.licenseStatus && status === 'to_check'));
    return (
      <div className="tm-col" style={{ borderTop: `4px solid ${color}` }}>
        <h4 style={{ fontSize: '0.75rem', color, textAlign: 'center', marginBottom: '10px' }}>{title} ({filteredPlayers.length})</h4>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: '8px' }}>
          {filteredPlayers.map(p => (
            <div key={p.id} className="tm-p-card">
              <div style={{ fontSize: '0.8rem', fontWeight: 'bold' }}>#{p.number} {p.name}</div>
              <div style={{ display: 'flex', gap: '5px', marginTop: '5px' }}>
                <input type="number" value={p.paid} onChange={(e) => updatePlayerFinance(team.id, p.id, 'paid', e.target.value)} className="tm-mini-input" />
                <input type="number" value={p.totalDue} onChange={(e) => updatePlayerFinance(team.id, p.id, 'totalDue', e.target.value)} className="tm-mini-input" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const getGroupStandings = (gNum) => {
    const groupTeams = tourney.teams.filter(t => t.groupId === gNum);
    return groupTeams.map(team => {
      let points = 0, diff = 0;
      tourney.schedule.filter(m => m.group === gNum && m.status === 'finished' && (m.teamA.id === team.id || m.teamB.id === team.id)).forEach(m => {
        const isA = m.teamA.id === team.id;
        const s = isA ? m.scoreA : m.scoreB; const o = isA ? m.scoreB : m.scoreA;
        if (s > o) points += 2; else points += 1;
        diff += (s - o);
      });
      return { ...team, points, diff };
    }).sort((a,b) => b.points - a.points || b.diff - a.diff);
  };

  if (editId) {
    const team = tourney.teams.find(t => t.id === editId);
    return (
      <div style={{ padding: '20px' }}>
        <button onClick={() => setEditId(null)} className="btn-tab">⬅ RETOUR</button>
        <div className="tm-flex-between" style={{ margin: '20px 0' }}>
            <h2>{team?.name}</h2>
            <div className="tm-flex-gap" style={{ gap: '10px' }}>
                <input className="tm-input" placeholder="Nom" value={pName} onChange={e => setPName(e.target.value)} />
                <input className="tm-input" style={{ width: '60px' }} type="number" placeholder="N°" value={pNum} onChange={e => setPNum(e.target.value)} />
                <button onClick={() => addPlayer(team.id)} className="tm-btn-success">+ AJOUTER</button>
            </div>
        </div>
        <div className="tm-flex-gap" style={{ gap: '20px', alignItems: 'flex-start' }}>
          {renderPlayerColumn("À vérifier", "to_check", "#ff4444", team)}
          {renderPlayerColumn("En attente", "pending", "var(--accent-orange)", team)}
          {renderPlayerColumn("Validé", "validated", "var(--success)", team)}
        </div>
      </div>
    );
  }

  const savedGroupIds = [...new Set(tourney.teams.map(t => t.groupId).filter(g => g !== null))].sort((a,b) => a-b);

  return (
    <div className="tm-container">
      <div className="tm-header">
        <h1 className="tm-title">{tourney.name}</h1>
        <div className="tm-tabs">
            <button onClick={() => setActiveTab("poules")} className={`tm-tab ${activeTab === "poules" ? 'active' : 'inactive'}`}>POULES</button>
            <button onClick={() => setActiveTab("finale")} className={`tm-tab ${activeTab === "finale" ? 'active' : 'inactive'}`}>PHASE FINALE</button>
        </div>
      </div>

      {activeTab === "poules" ? (
        <>
          <div className="tm-panel">
            <h3>1. Équipes et Licences</h3>
            <div className="tm-flex-gap" style={{ marginBottom: '20px' }}>
              <input className="tm-input" style={{ flex: 1 }} placeholder="Nom équipe..." value={teamName} onChange={(e) => setTeamName(e.target.value)} />
              <button onClick={addTeam} className="tm-btn-success">AJOUTER ÉQUIPE</button>
            </div>
            <div className="tm-grid-teams">
              {tourney.teams.map(t => (
                <div key={t.id} className="tm-card">
                  <b>{t.name}</b>
                  <div style={{ fontSize: '0.7rem', color: '#888', margin: '5px 0' }}>
                    {t.players.filter(p => p.licenseStatus === 'validated').length} / {t.players.length} licences OK
                  </div>
                  <button onClick={() => setEditId(t.id)} className="tm-small-btn">GÉRER LICENCES</button>
                </div>
              ))}
            </div>
          </div>

          <div className="tm-panel">
            <h3>2. Tirage au sort / Planning</h3>
            <div className="tm-flex-gap">
                <label>Nombre de poules :</label>
                <input type="number" min="1" value={groupCount} onChange={(e) => setGroupCount(e.target.value)} className="tm-input" style={{ width: '60px' }} />
                <button onClick={generateDrawAndSchedule} className="tm-btn-success tm-btn-purple">
                  🎲 NOUVEAU TIRAGE & PLANNING AUTO
                </button>
            </div>
          </div>

          <div style={{ display: 'flex', overflowX: 'auto', gap: '20px' }}>
            {savedGroupIds.map(gNum => {
                const standings = getGroupStandings(gNum);
                const limit = tourney.qualifiedSettings?.[gNum] || 2;
                return (
                  <div key={gNum} className="tm-group-col">
                    <div className="tm-flex-between" style={{ marginBottom: '10px' }}>
                      <h4 style={{ margin: 0 }}>POULE {gNum}</h4>
                      <div style={{ fontSize: '0.7rem', display: 'flex', alignItems: 'center', gap: '5px' }}>
                        <span>Qualifiés:</span>
                        <input type="number" value={limit} onChange={(e) => update({ qualifiedSettings: { ...tourney.qualifiedSettings, [gNum]: parseInt(e.target.value) || 0 } })} className="tm-mini-input" style={{ width: '35px' }} />
                      </div>
                    </div>
                    <table style={{ width: '100%', fontSize: '0.75rem', marginBottom: '15px' }}>
                      <thead><tr style={{ color: '#666', fontSize: '0.6rem' }}><th align="left">NOM</th><th align="right">PTS</th><th align="right">+/-</th></tr></thead>
                      <tbody>
                        {standings.map((team, idx) => (
                          <tr key={team.id} style={{ color: idx < limit ? '#fff' : '#444' }}>
                            <td>{idx + 1}. {team.name} {idx < limit && "⭐"}</td>
                            <td align="right">{team.points}</td>
                            <td align="right" style={{ color: team.diff > 0 ? 'var(--success)' : (team.diff < 0 ? 'var(--danger)' : '#666') }}>{team.diff > 0 ? `+${team.diff}` : team.diff}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {tourney.schedule.filter(m => m.group === gNum).map(m => {
                      const isReady = m.teamA.players?.length >= 5 && m.teamB.players?.length >= 5;
                      const isFinished = m.status === 'finished';
                      const canClick = isReady || isFinished;
                      
                      return (
                        <div 
                          key={m.id} 
                          onClick={() => {
                            if (!canClick) {
                              alert(`Impossible de lancer le match : ${m.teamA.name} ou ${m.teamB.name} n'a pas 5 joueurs inscrits.`);
                              return;
                            }
                            handleLaunchMatch(m.id);
                          }} 
                          className="tm-match-row"
                          style={{
                            borderLeft: `3px solid ${canClick ? 'var(--success)' : 'var(--danger)'}`,
                            cursor: canClick ? 'pointer' : 'not-allowed'
                          }}
                        >
                           <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
                             <div className="tm-flex-between">
                               <span style={{ fontSize: '0.8rem', color: isFinished ? (m.scoreA > m.scoreB ? 'var(--success)' : 'var(--danger)') : 'white', fontWeight: isFinished && m.scoreA > m.scoreB ? 'bold' : 'normal' }}>{m.teamA.name}</span>
                               {isFinished && <b style={{ color: m.scoreA > m.scoreB ? 'var(--success)' : 'var(--danger)' }}>{m.scoreA}</b>}
                             </div>
                             <div className="tm-flex-between">
                               <span style={{ fontSize: '0.8rem', color: isFinished ? (m.scoreB > m.scoreA ? 'var(--success)' : 'var(--danger)') : 'white', fontWeight: isFinished && m.scoreB > m.scoreA ? 'bold' : 'normal' }}>{m.teamB.name}</span>
                               {isFinished && <b style={{ color: m.scoreB > m.scoreA ? 'var(--success)' : 'var(--danger)' }}>{m.scoreB}</b>}
                             </div>
                           </div>
                           <button className={`tm-launch-btn ${canClick ? 'ready' : 'not-ready'}`}>{isFinished ? "STATS 📊" : "LANCER 🏀"}</button>
                        </div>
                      );
                    })}
                  </div>
                );
            })}
          </div>
        </>
      ) : (
        <div className="tm-panel">
          <div className="tm-flex-between" style={{ marginBottom: '20px' }}>
            <h3>🏆 Phase Finale</h3>
            {tourney.playoffs && <button onClick={() => update({playoffs: null})} style={{ background: 'none', border: '1px solid var(--danger)', color: 'var(--danger)', padding: '4px 8px', borderRadius: '4px', fontSize: '0.7rem', cursor: 'pointer' }}>RESET TABLEAU</button>}
          </div>
          {!tourney.playoffs ? (
            <div style={{ textAlign: 'center', padding: '40px', border: '1px dashed #333', borderRadius: '12px' }}>
                <p style={{ marginBottom: '20px' }}>Générer le tableau à partir des qualifiés ⭐ :</p>
                <div style={{ display: 'flex', gap: '15px', justifyContent: 'center' }}>
                    <button onClick={() => generatePlayoffs(2)} className="tm-btn-success">FINALE (2)</button>
                    <button onClick={() => generatePlayoffs(4)} className="tm-btn-success">DEMI-FINALES (4)</button>
                    <button onClick={() => generatePlayoffs(8)} className="tm-btn-success">QUARTS DE FINALE (8)</button>
                </div>
            </div>
          ) : (
            <div className="tm-grid-playoffs">
                {tourney.playoffs.matches.map(m => {
                    const isReady = m.teamA.players?.length >= 5 && m.teamB.players?.length >= 5;
                    const isFinished = m.status === 'finished';
                    const canClick = isReady || isFinished;
                    
                    return (
                        <div 
                          key={m.id} 
                          onClick={() => {
                            if (!canClick) {
                              alert(`Impossible de lancer : il manque des joueurs à ${m.teamA.name} ou ${m.teamB.name} (Minimum 5).`);
                              return;
                            }
                            handleLaunchMatch(m.id);
                          }} 
                          className="tm-match-row"
                          style={{ 
                            padding: '15px', 
                            background: isFinished ? '#1a1a1a' : '#111', 
                            borderLeft: `4px solid ${canClick ? 'var(--accent-orange)' : 'var(--danger)'}`,
                            cursor: canClick ? 'pointer' : 'not-allowed'
                          }}
                        >
                            <div style={{ fontSize: '0.7rem', color: 'var(--accent-orange)', fontWeight: 'bold', marginBottom: '10px' }}>{m.label}</div>
                            <div className="tm-flex-between" style={{ marginBottom: '8px' }}>
                                <span style={{ color: isFinished ? (m.scoreA > m.scoreB ? 'var(--success)' : 'var(--danger)') : 'white', fontWeight: isFinished && m.scoreA > m.scoreB ? 'bold' : 'normal' }}>{m.teamA.name}</span>
                                <b>{isFinished ? m.scoreA : '-'}</b>
                            </div>
                            <div className="tm-flex-between" style={{ marginBottom: '15px' }}>
                                <span style={{ color: isFinished ? (m.scoreB > m.scoreA ? 'var(--success)' : 'var(--danger)') : 'white', fontWeight: isFinished && m.scoreB > m.scoreA ? 'bold' : 'normal' }}>{m.teamB.name}</span>
                                <b>{isFinished ? m.scoreB : '-'}</b>
                            </div>
                            <button className={`tm-launch-btn ${canClick ? 'ready' : 'not-ready'}`}>{isFinished ? "VOIR LA FEUILLE 📊" : "LANCER LE MATCH 🏀"}</button>
                        </div>
                    );
                })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}